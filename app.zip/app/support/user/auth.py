# app/core/support/user/auth.py
