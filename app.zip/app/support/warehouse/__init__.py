# app/support/template/__init__.py
# база данных мест хранения
