# app/support/drink/__init__.py
"""
     drink
"""
