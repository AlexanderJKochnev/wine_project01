# app/support/category/__init__.py
"""
drink category
"""