# app/core/repositories/mongo_repository.py
