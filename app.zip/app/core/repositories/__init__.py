# app/core/repositories/__init__.py
"""
    взаимодействие с базами данных
"""