# app/core/services/__init__.py
"""
    бизнес логика
"""