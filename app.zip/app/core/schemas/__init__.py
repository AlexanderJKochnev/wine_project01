# app/core/schemas/__init__.py
"""
     модели pydantic
"""
